//
//  TestW04App.swift
//  TestW04
//
//  Created by Christian on 06/10/23.
//

import SwiftUI

@main
struct TestW04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
