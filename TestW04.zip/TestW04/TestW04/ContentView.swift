import SwiftUI

struct ContentView: View {
    var asean = ["Indonesia", "Singapore", "Malaysia", "Laos", "Philipines", "Cambodia", "Myanmar", "Thailand", "Brunei", "Vietnam"]
    @State var angkaRandom = Int.random(in: 0...9)
    @State var attempts = 0
    @State var correctAnswers = 0
    @State var wrongAnswers = 0
    @State var isGameActive = false
    @State var usedCountries: [String] = []
    @State var remainingCountries: [String] = []

    init() {
        self.remainingCountries = asean
    }

    var body: some View {
        ZStack{
            Color.blue
                .ignoresSafeArea()

            VStack{
                if isGameActive {
                    Text("Pilih Bendera dari Negara : ")
                        .foregroundStyle(.black)
                    Text(asean[angkaRandom])
                        .foregroundStyle(.black)
                } else {
                    Text("Game Selesai")
                        .foregroundStyle(.black)
                    Text("Benar: \(correctAnswers), Salah: \(wrongAnswers)")
                        .foregroundStyle(.black)
                }
            }
        }

        HStack{
            Spacer()
            VStack{
                ForEach(0..<5) { number in
                    Button {
                        if isGameActive {
                            flagTapped(number)
                        }
                    } label: {
                        Image(asean[number])
                            .resizable()
                            .frame(width: 105, height: 65)
                    }
                }
            }
            Spacer()
            VStack{
                ForEach(5..<10) { number in
                    Button {
                        if isGameActive {
                            flagTapped(number)
                        }
                    } label: {
                        Image(asean[number])
                            .resizable()
                            .frame(width: 105, height: 65)
                    }
                }
            }
            Spacer()
        }

        if isGameActive {
            Button("Mulai Game") {
                startGame()
            }
        } else {
            Button("Restart Game") {
                restartGame()
            }
        }
    }

    func flagTapped(_ flagIndex: Int) {
        let selectedCountry = asean[flagIndex]
        
        if remainingCountries.isEmpty {
            isGameActive = false // Menghentikan permainan jika sudah tidak ada negara yang tersisa
        }
        
        if flagIndex == angkaRandom {
            correctAnswers += 1
        } else {
            wrongAnswers += 1
        }
        attempts += 1

        if attempts < 10 {
            angkaRandom = generateUniqueRandomNumber()
        }
    }

    func generateUniqueRandomNumber() -> Int {
        guard !remainingCountries.isEmpty else {
            return 0  // Kembalikan nilai default jika tidak ada negara yang tersisa
        }

        let randomIndex = Int.random(in: 0..<remainingCountries.count)
        let selectedCountry = remainingCountries.remove(at: randomIndex)
        
        return asean.firstIndex(of: selectedCountry) ?? 0
    }


    func startGame() {
        attempts = 0
        correctAnswers = 0
        wrongAnswers = 0
        isGameActive = true
        usedCountries.removeAll()
        remainingCountries = asean
        angkaRandom = generateUniqueRandomNumber()
    }


    func restartGame() {
        attempts = 0
        correctAnswers = 0
        wrongAnswers = 0
        isGameActive = true
        usedCountries.removeAll()
        remainingCountries = asean
        angkaRandom = generateUniqueRandomNumber()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
